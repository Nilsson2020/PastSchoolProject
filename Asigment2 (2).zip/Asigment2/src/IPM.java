public interface IPM {


    float[] monthlyAvg(int year);

    float[] yearlyAvgPerC(int year);
    float sumOfMonth(int year, int month);

}

